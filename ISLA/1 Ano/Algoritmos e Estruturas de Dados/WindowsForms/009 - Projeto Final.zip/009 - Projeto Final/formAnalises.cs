﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace _009___Projeto_Final
{
    public partial class formAnalises : Form
    {
        public formAnalises()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Form formMenu = new formMenu();
            formMenu.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult resposta;
            resposta = MessageBox.Show("Queres mesmo sair?", "Atenção!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (resposta == DialogResult.Yes)
                Application.Exit();
        }

        private void tabPage2_Enter(object sender, EventArgs e)
        {
            //Query Total Vendas por Vendedor
            string query1 = "SELECT Vendedores.Nome, SUM(Vendas.Valor) AS TotalVendas FROM Vendedores, Vendas WHERE Vendedores.Codigo = Vendas.CodigoVendedor GROUP BY Vendedores.Nome";
            //Query Vendas por Produto
            string query2 = "SELECT Produtos.Nome, SUM(Vendas.Valor) AS TotalVendas FROM Produtos, Vendas WHERE Produtos.Codigo = Vendas.CodigoProduto GROUP BY Produtos.Nome";
            try
            {
                DatabaseManager db = new DatabaseManager();
                DataTable dt1 = db.SelectDataTable(query1);
                DataTable dt2 = db.SelectDataTable(query2);

                //Gráfico 1
                chart1.ChartAreas.Clear();
                chart1.Series.Clear();

                chart1.ChartAreas.Add("Area");
                chart1.Series.Add("Vendas");
                chart1.Series["Vendas"].ChartType = SeriesChartType.Bar;
                chart1.Series["Vendas"].XValueMember = "Nome";
                chart1.Series["Vendas"].YValueMembers = "TotalVendas";
                chart1.Series["Vendas"].IsValueShownAsLabel = true;

                chart1.DataSource = dt1;
                chart1.DataBind();

                chart1.Series["Vendas"]["MinimumBarDistance"] = "10";
                chart1.Series["Vendas"]["PointWidth"] = "0.6";
                chart1.Series["Vendas"]["BarWidth"] = "0.5"; 
                chart1.Series["Vendas"]["BarSpacingRatio"] = "50";

                //Gráfico 2
                chart2.Series.Clear();
                chart2.ChartAreas.Clear();
                
                chart2.Series.Add("Vendas");
                chart2.ChartAreas.Add("Area");
                chart2.Series["Vendas"].ChartType = SeriesChartType.Bar;
                chart2.Series["Vendas"].XValueMember = "Nome";
                chart2.Series["Vendas"].YValueMembers = "TotalVendas";
                chart2.Series["Vendas"].IsValueShownAsLabel = true;
                chart2.DataSource = dt2;
                chart2.DataBind();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
