﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _009___Projeto_Final
{
    internal class VariaveisGlobais
    {
        public static string Username; //Variavel global para guardar o username
    } // public para ser acessivel de qualquer lado
      // static para ser acessivel sem ser preciso criar uma instancia da classe
}
